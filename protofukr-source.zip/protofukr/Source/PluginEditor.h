#pragma once
#include "PluginProcessor.h"
#include "ui/PfLookAndFeel.h"
#include "ui/QaeruScare.h"

namespace ui
{
using APVTS = juce::AudioProcessorValueTreeState;

// Knob with caption and an editable value pill (click the pill and type an exact value).
struct Knob : juce::Component
{
    Knob (APVTS& s, const juce::String& id, const juce::String& caption, juce::Colour accent, bool small = false);
    void resized() override;
    void setCaption (const juce::String& c) { cap.setText (c, juce::dontSendNotification); }
    juce::Slider slider;
    juce::Label cap;
    std::unique_ptr<APVTS::SliderAttachment> att;
    bool small;
};

// Vertical fader with an LCD readout on top (typeable) and an optional quick-pick menu.
struct Fader : juce::Component
{
    Fader (APVTS& s, const juce::String& id, const juce::String& caption, juce::Colour accent);
    void resized() override;
    void setPicks (std::vector<std::pair<juce::String, float>> picks, std::function<void (float)> onPick);
    juce::Slider slider;
    juce::Label cap;
    juce::TextButton pick { juce::String::fromUTF8 ("\xe2\x96\xbc") };
    std::unique_ptr<APVTS::SliderAttachment> att;
    std::vector<std::pair<juce::String, float>> picks;
    std::function<void (float)> pickCb;
};

// Row of radio-style glossy buttons bound to a choice (or bool) parameter.
struct Segmented : juce::Component
{
    Segmented (APVTS& s, const juce::String& id, const juce::StringArray& labels, juce::Colour accent);
    void resized() override;
    juce::OwnedArray<juce::TextButton> buttons;
    std::unique_ptr<juce::ParameterAttachment> att;
    void update (float v);
};

struct Combo : juce::Component
{
    Combo (APVTS& s, const juce::String& id, const juce::StringArray& items);
    void resized() override { box.setBounds (getLocalBounds()); }
    juce::ComboBox box;
    std::unique_ptr<APVTS::ComboBoxAttachment> att;
};

struct Toggle : juce::Component
{
    Toggle (APVTS& s, const juce::String& id, const juce::String& text, juce::Colour accent);
    void resized() override { b.setBounds (getLocalBounds()); }
    juce::ToggleButton b;
    std::unique_ptr<APVTS::ButtonAttachment> att;
};

struct Panel : juce::Component
{
    Panel (const juce::String& t, juce::Colour a) : title (t), accent (a) { setInterceptsMouseClicks (false, true); }
    void paint (juce::Graphics& g) override;
    juce::Rectangle<int> content() const { return getLocalBounds().reduced (10, 0).withTrimmedTop (38).withTrimmedBottom (8); }
    juce::Rectangle<int> headerRight (int w) const { return { getWidth() - 10 - w, 6, w, 20 }; }
    juce::String title;
    juce::Colour accent;
};

struct WarpLcd : juce::Component
{
    explicit WarpLcd (ProtofukrProcessor& p) : proc (p) {}
    void paint (juce::Graphics&) override;
    ProtofukrProcessor& proc;
    std::vector<float> peaks; juce::String sampleName;
};

struct LofiLcd : juce::Component
{
    explicit LofiLcd (ProtofukrProcessor& p) : proc (p), fft (11) {}
    void paint (juce::Graphics&) override;
    ProtofukrProcessor& proc;
    juce::dsp::FFT fft;
    std::array<float, 4096> work {};
    std::array<float, 64> bars {};
};

struct Meter : juce::Component
{
    std::function<float()> get; bool reduction = false; juce::String label;
    float shown = 0;
    void paint (juce::Graphics&) override;
};
} // namespace ui

class ProtofukrEditor : public juce::AudioProcessorEditor, public juce::FileDragAndDropTarget, private juce::Timer
{
public:
    explicit ProtofukrEditor (ProtofukrProcessor&);
    ~ProtofukrEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    bool keyPressed (const juce::KeyPress&) override;
    void mouseDown (const juce::MouseEvent&) override { grabKeyboardFocus(); }

    bool isInterestedInFileDrag (const juce::StringArray&) override { return true; }
    void filesDropped (const juce::StringArray& files, int, int) override;

    void triggerScare();
    QaeruScare& getScare() { return scare; }   // used by the offline test renderer

private:
    void timerCallback() override;
    void refreshPresetBox();
    void refreshFxLabels();
    void openSampleChooser();

    ProtofukrProcessor& proc;
    PfLookAndFeel lnf;
    juce::TooltipWindow tips { this, 600 };

    // top bar
    juce::ComboBox presetBox;
    juce::TextButton prevPreset { "<" }, nextPreset { ">" };
    std::unique_ptr<ui::Segmented> stereoSeg;
    std::unique_ptr<ui::Knob> inKnob, outKnob, mixKnob, widthKnob;
    std::unique_ptr<ui::Combo> orderBox;
    ui::Meter inMeter, outMeter;

    // panels
    ui::Panel warpPanel { "WARP", theme::lavender }, lofiPanel { "LOFI", theme::pink }, tapePanel { "TAPE", theme::mint },
              dynPanel { "DYNAMICS", theme::peach }, fxPanel { "INSERT FX", theme::sky };

    // warp
    std::unique_ptr<ui::Segmented> warpMode, warpAlgo;
    std::unique_ptr<ui::Fader> warpSpeed;
    std::unique_ptr<ui::Knob> warpPitch, warpGrain, warpFlux, warpEnv, warpMix;
    std::unique_ptr<ui::Combo> warpLoop, warpPres, warpLen, warpDir;
    std::unique_ptr<ui::Toggle> warpFreeze, warpSync, warpFreeRun;
    std::unique_ptr<ui::Knob> warpBpm;
    juce::TextButton loadBtn { "LOAD SAMPLE" };
    ui::WarpLcd warpLcd;

    // lofi
    std::unique_ptr<ui::Toggle> lofiOn;
    std::unique_ptr<ui::Segmented> codecType;
    std::unique_ptr<ui::Fader> codecSR, codecKbps, codecBits;
    std::unique_ptr<ui::Knob> codecSwirl, lofiMix;
    std::unique_ptr<ui::Combo> codecFrame, codecStereo;
    std::unique_ptr<ui::Toggle> codecDither;
    ui::LofiLcd lofiLcd;

    // tape
    std::unique_ptr<ui::Toggle> tapeOn, hissOn;
    std::unique_ptr<ui::Combo> hissType, hissSc;
    std::unique_ptr<ui::Knob> hissLevel, hissTone, hissScAmt, hissScAtk, hissScRel, wow, flutter, drive;

    // dynamics
    std::unique_ptr<ui::Segmented> transMode;
    std::unique_ptr<ui::Knob> transAtk, transSus, transFocus;
    std::unique_ptr<ui::Toggle> compOn;
    std::unique_ptr<ui::Combo> compStyle;
    juce::TextButton compPresetBtn { "PRESETS" };
    std::unique_ptr<ui::Knob> cThr, cRatio, cAtk, cRel, cKnee, cMake, cMix;
    ui::Meter grMeter;

    // inserts
    std::unique_ptr<ui::Toggle> fxOn[2];
    std::unique_ptr<ui::Combo> fxType[2];
    std::unique_ptr<ui::Knob> fxA[2], fxB[2], fxC[2], fxMix[2];
    int shownFxType[2] { -1, -1 };

    QaeruScare scare;
    juce::String typed;
    std::unique_ptr<juce::FileChooser> chooser;
    int shownProgram = -1;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ProtofukrEditor)
};
