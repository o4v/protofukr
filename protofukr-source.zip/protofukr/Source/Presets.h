#pragma once
// protofukr — factory presets, compression presets and quick-pick lists for typeable sliders.
#include "Parameters.h"
#include <vector>
#include <utility>

struct Preset
{
    const char* name;
    std::vector<std::pair<juce::String, float>> values;   // real (un-normalised) values; unspecified params → default
};

// Quick-pick menus beside the LOFI sliders
inline const std::vector<std::pair<const char*, float>> kSampleRatePicks {
    { "4 kHz (toy)", 4000 }, { "6 kHz", 6000 }, { "8 kHz (phone)", 8000 }, { "11.025 kHz", 11025 }, { "16 kHz", 16000 },
    { "22.05 kHz (YouTube '08 SQ)", 22050 }, { "24 kHz", 24000 }, { "32 kHz", 32000 }, { "44.1 kHz (CD / YT HQ)", 44100 }, { "48 kHz", 48000 } };

inline const std::vector<std::pair<const char*, float>> kBitratePicks {
    { "8 kbps", 8 }, { "16 kbps", 16 }, { "24 kbps", 24 }, { "32 kbps", 32 }, { "48 kbps", 48 }, { "56 kbps", 56 },
    { "64 kbps (YouTube '08 SQ)", 64 }, { "96 kbps", 96 }, { "128 kbps", 128 }, { "160 kbps", 160 }, { "192 kbps", 192 },
    { "256 kbps", 256 }, { "320 kbps (max)", 320 } };

inline const std::vector<std::pair<const char*, float>> kBitDepthPicks {
    { "4 bit", 4 }, { "6 bit", 6 }, { "8 bit", 8 }, { "10 bit", 10 }, { "12 bit (SP-1200-ish)", 12 }, { "16 bit", 16 }, { "24 bit (off)", 24 } };

// Compressor presets (style index, thr, ratio, atk, rel, knee, makeup, mix)
struct CompPreset { const char* name; float style, thr, ratio, atk, rel, knee, makeup, mix; };
inline const std::vector<CompPreset> kCompPresets {
    { "Screw Tape Glue",    3, -22.0f, 3.0f,  30.0f, 400.0f, 10.0f, 5.0f,  100.0f },
    { "Soundcloud Smash",   4, -14.0f, 20.0f, 0.3f,  60.0f,  1.0f,  10.0f, 100.0f },
    { "Lofi Bus",           1, -20.0f, 3.0f,  15.0f, 300.0f, 12.0f, 4.0f,  80.0f  },
    { "Vapor Pump",         5, -26.0f, 6.0f,  8.0f,  350.0f, 6.0f,  7.0f,  100.0f },
    { "Drum Punch (FET)",   2, -18.0f, 6.0f,  6.0f,  90.0f,  3.0f,  5.0f,  100.0f },
    { "Parallel NY Crush",  2, -32.0f, 12.0f, 0.5f,  70.0f,  2.0f,  12.0f, 40.0f  },
    { "Gentle Opto",        1, -16.0f, 2.5f,  20.0f, 250.0f, 10.0f, 2.0f,  100.0f },
    { "Vocal Sit (VCA)",    0, -20.0f, 4.0f,  5.0f,  120.0f, 6.0f,  4.0f,  100.0f },
    { "Boom-Bap Knock",     2, -24.0f, 8.0f,  12.0f, 110.0f, 4.0f,  7.0f,  70.0f  },
};

inline const std::vector<Preset>& factoryPresets()
{
    using namespace pid;
    static const std::vector<Preset> p {
        { "Init", {} },

        { "YouTube '08 SQ (22k / 64k MP3)", {
            { lofiOn, 1 }, { codecType, 3 }, { codecSR, 22050 }, { codecKbps, 64 }, { codecStereo, 2 }, { codecFrame, 0 }, { codecSwirl, 15 } } },

        { "YouTube '08 HQ (44.1k AAC)", {
            { lofiOn, 1 }, { codecType, 4 }, { codecSR, 44100 }, { codecKbps, 96 }, { codecStereo, 1 } } },

        { "Signalwave Broadcast", {
            { lofiOn, 1 }, { codecType, 3 }, { codecSR, 22050 }, { codecKbps, 32 }, { codecStereo, 1 }, { codecSwirl, 45 }, { codecFrame, 4 },
            { tapeOn, 1 }, { wow, 22 }, { flutter, 18 }, { tapeDrive, 25 },
            { hissOn, 1 }, { hissType, 6 }, { hissLevel, -38 }, { hissSc, 2 }, { hissScAmt, 60 },
            { fx (1, "On"), 1 }, { fx (1, "Type"), 15 }, { fx (1, "A"), 10 }, { fx (1, "B"), 60 }, { fx (1, "C"), 40 }, { fx (1, "Mix"), 70 } } },

        { "Mediafire Rip (32k joint)", {
            { lofiOn, 1 }, { codecType, 3 }, { codecSR, 22050 }, { codecKbps, 32 }, { codecStereo, 1 }, { codecSwirl, 30 }, { codecFrame, 3 } } },

        { "Plaza Slowdown", {
            { warpMode, 1 }, { warpAlgo, 3 }, { warpSpeed, 0.84f }, { warpLength, 5 }, { warpSync, 1 },
            { lofiOn, 1 }, { codecType, 3 }, { codecSR, 32000 }, { codecKbps, 96 }, { codecStereo, 1 },
            { fx (2, "On"), 1 }, { fx (2, "Type"), 14 }, { fx (2, "A"), 75 }, { fx (2, "B"), 60 }, { fx (2, "C"), 35 }, { fx (2, "Mix"), 100 } } },

        { "Chopped & Screwed", {
            { warpMode, 1 }, { warpAlgo, 3 }, { warpSpeed, 0.75f }, { warpLength, 4 }, { warpSync, 1 },
            { compOn, 1 }, { compStyle, 3 }, { compThresh, -22 }, { compRatio, 3 }, { compAttack, 30 }, { compRelease, 400 }, { compKnee, 10 }, { compMakeup, 5 },
            { transMode, 2 }, { transAttack, 25 }, { transSustain, 20 },
            { fx (1, "On"), 1 }, { fx (1, "Type"), 8 }, { fx (1, "A"), 30 }, { fx (1, "B"), 25 }, { fx (1, "C"), 100 }, { fx (1, "Mix"), 100 },
            { tapeOn, 1 }, { wow, 10 }, { tapeDrive, 30 } } },

        { "Maxell Tape Dub", {
            { tapeOn, 1 }, { wow, 18 }, { flutter, 25 }, { tapeDrive, 45 },
            { hissOn, 1 }, { hissType, 0 }, { hissLevel, -36 }, { hissSc, 1 }, { hissScAmt, 55 }, { hissScRel, 300 },
            { transMode, 2 }, { transAttack, 30 }, { transSustain, 15 } } },

        { "Soundcloud Smash", {
            { transMode, 1 }, { transAttack, 60 }, { transSustain, -10 },
            { compOn, 1 }, { compStyle, 4 }, { compThresh, -14 }, { compRatio, 20 }, { compAttack, 0.3f }, { compRelease, 60 }, { compKnee, 1 }, { compMakeup, 10 },
            { lofiOn, 1 }, { codecType, 3 }, { codecSR, 44100 }, { codecKbps, 128 }, { codecStereo, 1 } } },

        { "Late Night Sleepcore", {
            { warpMode, 1 }, { warpAlgo, 4 }, { warpSpeed, 0.7f }, { warpLength, 6 }, { warpPitch, -2 },
            { lofiOn, 1 }, { codecType, 3 }, { codecSR, 22050 }, { codecKbps, 48 }, { codecSwirl, 25 },
            { hissOn, 1 }, { hissType, 2 }, { hissLevel, -44 },
            { fx (2, "On"), 1 }, { fx (2, "Type"), 14 }, { fx (2, "A"), 90 }, { fx (2, "B"), 40 }, { fx (2, "C"), 45 } } },

        { "Glitter Static", {
            { lofiOn, 1 }, { codecType, 1 }, { codecSR, 16000 }, { codecBits, 12 },
            { transMode, 5 }, { transAttack, 70 },
            { fx (1, "On"), 1 }, { fx (1, "Type"), 15 }, { fx (1, "A"), 50 }, { fx (1, "B"), 70 }, { fx (1, "C"), 50 },
            { fx (2, "On"), 1 }, { fx (2, "Type"), 12 }, { fx (2, "A"), 40 }, { fx (2, "B"), 45 }, { fx (2, "C"), 35 } } },

        { "Mystic Dust (Texture)", {
            { warpMode, 1 }, { warpAlgo, 2 }, { warpSpeed, 0.5f }, { warpGrain, 140 }, { warpFlux, 70 }, { warpLength, 5 },
            { lofiOn, 1 }, { codecType, 3 }, { codecSR, 22050 }, { codecKbps, 56 },
            { fx (2, "On"), 1 }, { fx (2, "Type"), 14 }, { fx (2, "A"), 85 }, { fx (2, "B"), 30 }, { fx (2, "C"), 50 } } },

        { "Mallsoft Hallway", {
            { lofiOn, 1 }, { codecType, 2 }, { codecSR, 11025 },
            { fx (1, "On"), 1 }, { fx (1, "Type"), 1 }, { fx (1, "A"), 80 }, { fx (1, "B"), 70 }, { fx (1, "C"), 45 },
            { fx (2, "On"), 1 }, { fx (2, "Type"), 14 }, { fx (2, "A"), 100 }, { fx (2, "B"), 50 }, { fx (2, "C"), 60 } } },

        { "RealPlayer '99", {
            { lofiOn, 1 }, { codecType, 5 }, { codecSR, 22050 }, { codecKbps, 20 }, { codecStereo, 2 }, { codecSwirl, 20 } } },

        { "Phone Call", {
            { lofiOn, 1 }, { codecType, 6 }, { codecSR, 8000 }, { codecKbps, 13 }, { codecStereo, 2 }, { mono, 1 } } },

        { "Beats Stutter Gate", {
            { warpMode, 1 }, { warpAlgo, 0 }, { warpSpeed, 0.5f }, { warpLoop, 2 }, { warpEnv, 55 }, { warpPreserve, 1 }, { warpLength, 4 } } },

        { "Tape Stop Throw", {
            { fx (1, "On"), 1 }, { fx (1, "Type"), 11 }, { fx (1, "A"), 30 }, { fx (1, "B"), 0 }, { fx (1, "C"), 0 } } },
    };
    return p;
}
