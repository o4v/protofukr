#pragma once
// protofukr — visual theme: brushed-grey chassis, pastel section accents, glossy candy controls,
// green LCD readouts. Fonts: Dela Gothic One (headers/logo, Latin subset) + VT323 (LCD/values), both SIL OFL.
#include <juce_gui_basics/juce_gui_basics.h>
#include "BinaryData.h"

namespace theme
{
inline const juce::Colour chassis      { 0xffc9cbd1 };
inline const juce::Colour chassisLight { 0xffe7e8ec };
inline const juce::Colour chassisDark  { 0xff8f939c };
inline const juce::Colour groove       { 0xff5d616b };
inline const juce::Colour ink          { 0xff383b44 };
inline const juce::Colour inkSoft      { 0xff6c707a };
inline const juce::Colour pink         { 0xfff3a8c9 };
inline const juce::Colour hot          { 0xffe0558e };
inline const juce::Colour lavender     { 0xffb9a7ec };
inline const juce::Colour mint         { 0xffa6dbbf };
inline const juce::Colour peach        { 0xfff7c49c };
inline const juce::Colour sky          { 0xffa7cdf1 };
inline const juce::Colour lcdBg        { 0xffcfe2c2 };
inline const juce::Colour lcdInk       { 0xff2f4a34 };

inline juce::Typeface::Ptr headerFace()
{
    static auto tf = juce::Typeface::createSystemTypefaceFor (BinaryData::DelaGothicOneLatin_ttf, BinaryData::DelaGothicOneLatin_ttfSize);
    return tf;
}
inline juce::Typeface::Ptr lcdFace()
{
    static auto tf = juce::Typeface::createSystemTypefaceFor (BinaryData::VT323Regular_ttf, BinaryData::VT323Regular_ttfSize);
    return tf;
}
inline juce::Font header (float h) { return juce::Font (juce::FontOptions (headerFace()).withHeight (h)); }
inline juce::Font lcd (float h)    { return juce::Font (juce::FontOptions (lcdFace()).withHeight (h)); }
inline juce::Font label (float h)  { return juce::Font (juce::FontOptions (h, juce::Font::bold)); }

// soft glossy fill for any rounded shape
inline void glossFill (juce::Graphics& g, juce::Rectangle<float> r, juce::Colour base, float corner)
{
    juce::ColourGradient grad (base.brighter (0.35f), r.getX(), r.getY(), base.darker (0.25f), r.getX(), r.getBottom(), false);
    grad.addColour (0.5, base);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (r, corner);
    auto hl = r.reduced (r.getWidth() * 0.08f, 0).withHeight (r.getHeight() * 0.45f).translated (0, 1.5f);
    g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.65f), hl.getX(), hl.getY(),
                                             juce::Colours::white.withAlpha (0.0f), hl.getX(), hl.getBottom(), false));
    g.fillRoundedRectangle (hl, std::max (0.0f, corner - 1.5f));
    g.setColour (base.darker (0.6f).withAlpha (0.8f));
    g.drawRoundedRectangle (r.reduced (0.5f), corner, 1.0f);
}
} // namespace theme
