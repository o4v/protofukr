#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include "Parameters.h"
#include "dsp/LofiCodec.h"
#include "dsp/TapeSection.h"
#include "dsp/Dynamics.h"
#include "dsp/InsertFX.h"
#include "dsp/WarpEngine.h"

class ProtofukrProcessor : public juce::AudioProcessor, private juce::Timer
{
public:
    ProtofukrProcessor();
    ~ProtofukrProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "protofukr"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 4.0; }

    int getNumPrograms() override;
    int getCurrentProgram() override { return currentProgram; }
    void setCurrentProgram (int) override;
    const juce::String getProgramName (int) override;
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    // UI helpers (message thread)
    void applyPreset (int index);
    void setParam (const juce::String& id, float realValue);
    bool loadSample (const juce::File& f);
    juce::String getSampleName() const;
    std::vector<float> getSamplePeaks() const;

    juce::AudioProcessorValueTreeState apvts;

    // metering (audio → UI)
    std::atomic<float> inPeak { 0 }, outPeak { 0 }, compGr { 0 }, codecBandwidth { 22050 };
    std::atomic<float> warpPlayhead { 0 };
    std::atomic<int> codecHop { 0 };
    static constexpr int kScopeSize = 2048;
    float scope[kScopeSize] {};
    std::atomic<int> scopeWrite { 0 };

private:
    void timerCallback() override;
    void processChunk (float* L, float* R, const float* scL, const float* scR, int n, double bpm, double ppq, bool playing);

    struct P;                                   // cached raw parameter pointers
    std::unique_ptr<P> p;

    pf::WarpEngine warp;
    pf::TransientShaper trans;
    pf::Compressor comp;
    pf::InsertFX fx[2];
    pf::TapeSection tape;
    pf::LofiCodec codec;
    pf::DelayLine dryDelay[2];
    pf::Smooth inG, outG, mixS, widthS;

    juce::AudioBuffer<float> dryBuf;
    double sr = 44100.0;
    std::atomic<int> wantedLatency { 0 };
    int currentProgram = 0;

    juce::SpinLock sampleLock;
    juce::String samplePath;
    juce::AudioFormatManager formats;
    std::shared_ptr<bool> alive = std::make_shared<bool> (true);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ProtofukrProcessor)
};
