#pragma once
// protofukr — TAPE section: hiss/noise beds with sidechain, wow & flutter, tape drive.
#include "Common.h"

namespace pf
{
class TapeSection
{
public:
    enum HissType { CheapFerric = 0, FerricNormal, Chrome, Metal, Microcassette, VHS, CRTBroadcast, VinylDust, NumHiss };
    enum ScSource { ScConstant = 0, ScAllInput, ScDuckInput, ScLowBand, ScHighBand, ScExternal, NumSc };

    struct Params
    {
        bool  hissOn = false;
        int   hissType = CheapFerric;
        float hissDb = -42.0f;
        float tone = 0.0f;         // -1 dark .. +1 bright
        int   scSource = ScConstant;
        float scAmount = 1.0f;     // 0..1
        float scAttackMs = 5.0f, scReleaseMs = 150.0f;
        float wow = 0.0f, flutter = 0.0f;   // 0..1
        float drive = 0.0f;        // 0..1 tape saturation + HF loss
    };

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        for (int c = 0; c < 2; ++c)
        {
            delay[c].prepare ((size_t) (sr * 0.03));
            for (auto& b : shape[c]) b.reset();
            lowBand[c].reset(); highBand[c].reset(); pink[c] = {};
            hfLoss[c].reset();
        }
        lowBand[0].setLP (sr, 150.0f); lowBand[1].setLP (sr, 150.0f);
        highBand[0].setLP (sr, 4000.0f); highBand[1].setLP (sr, 4000.0f);
        env.reset(); wowPhase = flutPhase = 0; wowDrift = 0; humPhase = whinePhase = 0; headPhase = 0;
        lastType = -1; lastTone = 99.0f;
    }

    // ext may be null. Returns nothing; adds hiss in place.
    void process (float* L, float* R, const float* extL, const float* extR, int n, const Params& p)
    {
        const bool stereo = R != nullptr;

        // ---- wow & flutter (shared transport, like a real tape path) + drive ----
        const bool wf = p.wow > 0.0001f || p.flutter > 0.0001f;
        const float wowDepth = p.wow * 0.0045f * (float) sr;       // up to 4.5 ms
        const float flutDepth = p.flutter * 0.0004f * (float) sr;  // up to 0.4 ms
        if (p.drive > 0.001f)
        {
            hfLoss[0].setLP (sr, 18000.0f - 12000.0f * p.drive);
            hfLoss[1].setLP (sr, 18000.0f - 12000.0f * p.drive);
        }
        for (int i = 0; i < n; ++i)
        {
            float d = 1.0f;
            if (wf)
            {
                wowDrift += (rng.bi() * 0.002f - wowDrift * 0.0005f);
                wowPhase += (0.45f + 0.25f * wowDrift) / (float) sr;
                flutPhase += (7.3f + 2.0f * rng.bi()) / (float) sr;
                if (wowPhase > 1.0f) wowPhase -= 1.0f;
                if (flutPhase > 1.0f) flutPhase -= 1.0f;
                d += wowDepth * (1.0f + std::sin (kTau * wowPhase) + 0.3f * wowDrift)
                   + flutDepth * (1.0f + std::sin (kTau * flutPhase));
            }
            for (int c = 0; c < (stereo ? 2 : 1); ++c)
            {
                float* x = c == 0 ? L : R;
                float v = x[i];
                if (p.drive > 0.001f)
                {
                    const float g = 1.0f + p.drive * 6.0f;
                    v = asymSat (v * g, 0.08f * p.drive) / std::sqrt (g);
                    v = hfLoss[c].lp (v);
                }
                if (wf) { delay[c].push (v); v = delay[c].read (std::max (1.0f, d)); }
                x[i] = v;
            }
        }

        if (! p.hissOn) return;

        // ---- hiss voicing ----
        if (p.hissType != lastType || std::abs (p.tone - lastTone) > 0.001f) configureShape (p.hissType, p.tone);

        env.prepare (sr, p.scAttackMs, p.scReleaseMs);
        const float level = dbToGain (p.hissDb);

        for (int i = 0; i < n; ++i)
        {
            // sidechain detector
            float scIn = 0.0f;
            switch (p.scSource)
            {
                case ScAllInput: case ScDuckInput: scIn = std::max (std::abs (L[i]), stereo ? std::abs (R[i]) : 0.0f); break;
                case ScLowBand:  scIn = std::abs (lowBand[0].lp (L[i] + (stereo ? R[i] : L[i])) * 0.5f) * 2.0f; break;
                case ScHighBand: { const float m = 0.5f * (L[i] + (stereo ? R[i] : L[i])); scIn = std::abs (highBand[0].hp (m)) * 2.5f; break; }
                case ScExternal: scIn = extL ? std::max (std::abs (extL[i]), extR ? std::abs (extR[i]) : 0.0f) : 0.0f; break;
                default: break;
            }
            float g = 1.0f;
            if (p.scSource != ScConstant)
            {
                const float e = clampf (env.process (scIn) * 4.0f, 0.0f, 1.0f);
                const float f = (p.scSource == ScDuckInput) ? 1.0f - e : e;
                g = (1.0f - p.scAmount) + p.scAmount * f;
            }
            const float a = level * g;
            L[i] += a * noiseSample (0, p.hissType);
            if (stereo) R[i] += a * noiseSample (1, p.hissType);
        }
    }

private:
    struct Pink { float b0 = 0, b1 = 0, b2 = 0; };

    void configureShape (int type, float tone)
    {
        lastType = type; lastTone = tone;
        for (int c = 0; c < 2; ++c)
        {
            auto& s = shape[c];
            switch (type)
            {
                case CheapFerric:   // bright, gritty: emphasis near 6–8 kHz, little top-end loss
                    s[0].set (Biquad::Peak, sr, 7000.0f, 0.7f, 6.0f);
                    s[1].set (Biquad::LP, sr, 15000.0f, 0.707f);
                    s[2].set (Biquad::HP, sr, 120.0f, 0.707f); break;
                case FerricNormal:
                    s[0].set (Biquad::Peak, sr, 5000.0f, 0.8f, 3.0f);
                    s[1].set (Biquad::LP, sr, 12000.0f, 0.707f);
                    s[2].set (Biquad::HP, sr, 80.0f, 0.707f); break;
                case Chrome:        // darker, smoother
                    s[0].set (Biquad::Peak, sr, 3000.0f, 0.6f, 1.5f);
                    s[1].set (Biquad::LP, sr, 8500.0f, 0.707f);
                    s[2].set (Biquad::HP, sr, 60.0f, 0.707f); break;
                case Metal:
                    s[0].set (Biquad::Peak, sr, 2500.0f, 0.5f, 0.0f);
                    s[1].set (Biquad::LP, sr, 7000.0f, 0.707f);
                    s[2].set (Biquad::HP, sr, 50.0f, 0.707f); break;
                case Microcassette:
                    s[0].set (Biquad::Peak, sr, 2500.0f, 1.2f, 7.0f);
                    s[1].set (Biquad::LP, sr, 5500.0f, 1.0f);
                    s[2].set (Biquad::HP, sr, 400.0f, 0.9f); break;
                case VHS:
                    s[0].set (Biquad::Peak, sr, 4500.0f, 0.7f, 4.0f);
                    s[1].set (Biquad::LP, sr, 10000.0f, 0.707f);
                    s[2].set (Biquad::HP, sr, 70.0f, 0.707f); break;
                case CRTBroadcast:  // white static
                    s[0].set (Biquad::Peak, sr, 9000.0f, 0.5f, 2.0f);
                    s[1].set (Biquad::LP, sr, 19000.0f, 0.707f);
                    s[2].set (Biquad::HP, sr, 200.0f, 0.707f); break;
                default:            // vinyl: rumble + soft surface noise
                    s[0].set (Biquad::Peak, sr, 1200.0f, 0.5f, -3.0f);
                    s[1].set (Biquad::LP, sr, 7000.0f, 0.707f);
                    s[2].set (Biquad::HP, sr, 25.0f, 0.707f); break;
            }
            s[3].set (Biquad::HighShelf, sr, 3000.0f, 0.707f, tone * 9.0f);
            for (auto& b : s) b.reset();
        }
    }

    inline float noiseSample (int c, int type)
    {
        // pink-ish base (Paul Kellet economy) + white
        const float w = rng.gauss() * 0.35f;
        auto& pk = pink[c];
        pk.b0 = 0.99765f * pk.b0 + w * 0.0990460f;
        pk.b1 = 0.96300f * pk.b1 + w * 0.2965164f;
        pk.b2 = 0.57000f * pk.b2 + w * 1.0526913f;
        const float pinkS = (pk.b0 + pk.b1 + pk.b2 + w * 0.1848f) * 0.25f;
        float v = (type == CRTBroadcast || type == CheapFerric) ? 0.4f * pinkS + 0.9f * w : 0.8f * pinkS + 0.4f * w;

        auto& s = shape[c];
        for (auto& b : s) v = b.process (v);

        if (c == 0)
        {
            humPhase += 60.0f / (float) sr;      if (humPhase >= 1.0f) humPhase -= 1.0f;
            headPhase += 59.94f / (float) sr;    if (headPhase >= 1.0f) headPhase -= 1.0f;
            whinePhase += 15734.0f / (float) sr; if (whinePhase >= 1.0f) whinePhase -= 1.0f;
        }
        switch (type)
        {
            case Microcassette: v += 0.05f * std::sin (kTau * humPhase * 3.3f) * (0.6f + 0.4f * rng.uni()); break;
            case VHS:
                v += 0.08f * std::sin (kTau * humPhase);
                if (headPhase < 0.015f) v += 0.6f * rng.bi();                 // head-switching buzz burst
                break;
            case CRTBroadcast:
                v += 0.04f * std::sin (kTau * humPhase) + 0.02f * std::sin (kTau * humPhase * 3.0f);
                if (15734.0f < (float) sr * 0.48f) v += 0.06f * std::sin (kTau * whinePhase);   // flyback whine
                break;
            case VinylDust:
            {
                const float r = rng.uni();
                if (r < 0.00025f) crackle[c] = (rng.bi() > 0 ? 1.0f : -1.0f) * (0.5f + rng.uni());
                v += crackle[c]; crackle[c] *= 0.6f;
                break;
            }
            default: break;
        }
        return v;
    }

    double sr = 44100.0;
    DelayLine delay[2];
    Biquad shape[2][4];
    OnePole lowBand[2], highBand[2], hfLoss[2];
    Pink pink[2];
    EnvFollow env;
    Rng rng { 0x7A9Eu };
    float wowPhase = 0, flutPhase = 0, wowDrift = 0, humPhase = 0, headPhase = 0, whinePhase = 0;
    float crackle[2] {};
    int lastType = -1; float lastTone = 99.0f;
};
} // namespace pf
