#pragma once
// protofukr — shared DSP helpers. Header-only, allocation-free after prepare().
#include <cmath>
#include <cstdint>
#include <vector>
#include <algorithm>

namespace pf
{
constexpr float kPi  = 3.14159265358979323846f;
constexpr float kTau = 6.28318530717958647692f;

inline float dbToGain (float db)  { return db <= -100.0f ? 0.0f : std::pow (10.0f, db * 0.05f); }
inline float gainToDb (float g)   { return g <= 1.0e-5f ? -100.0f : 20.0f * std::log10 (g); }
inline float clampf (float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }

// Kill denormals / NaN guards
inline float sanitize (float x) { return (std::isfinite (x) && std::abs (x) > 1.0e-20f) ? x : 0.0f; }

// Fast xorshift RNG (audio-thread safe, no locks)
struct Rng
{
    uint32_t s = 0x9E3779B9u;
    explicit Rng (uint32_t seed = 0x9E3779B9u) : s (seed ? seed : 1u) {}
    inline uint32_t next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    inline float uni()     { return (float) (next() >> 8) * (1.0f / 16777216.0f); }   // [0,1)
    inline float bi()      { return uni() * 2.0f - 1.0f; }                               // [-1,1)
    inline float gauss()   { float a = uni() + uni() + uni() + uni(); return (a - 2.0f) * 1.7320508f; }
};

// One-pole parameter smoother
struct Smooth
{
    float cur = 0, target = 0, coef = 0.999f;
    void prepare (double sr, float ms = 20.0f) { coef = std::exp (-1.0f / (float) (sr * ms * 0.001)); }
    void reset (float v) { cur = target = v; }
    void set (float v)   { target = v; }
    inline float next()  { cur = target + (cur - target) * coef; return cur; }
};

// Simple one-pole lowpass / highpass
struct OnePole
{
    float a = 0, z = 0;
    void setLP (double sr, float hz) { a = std::exp (-kTau * clampf (hz, 1.0f, (float) sr * 0.49f) / (float) sr); }
    inline float lp (float x) { z = x + (z - x) * a; return z; }
    inline float hp (float x) { return x - lp (x); }
    void reset() { z = 0; }
};

// Envelope follower with separate attack/release
struct EnvFollow
{
    float a = 0, r = 0, env = 0;
    void prepare (double sr, float atkMs, float relMs)
    {
        a = std::exp (-1.0f / (float) (sr * std::max (0.01f, atkMs) * 0.001));
        r = std::exp (-1.0f / (float) (sr * std::max (0.01f, relMs) * 0.001));
    }
    inline float process (float x)
    {
        x = std::abs (x);
        env = x > env ? x + (env - x) * a : x + (env - x) * r;
        return env;
    }
    void reset() { env = 0; }
};

// RBJ biquad (transposed direct form II)
struct Biquad
{
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
    enum Type { LP, HP, BP, Peak, LowShelf, HighShelf, Notch };
    void set (Type t, double sr, float f, float q, float gainDb = 0.0f)
    {
        f = clampf (f, 5.0f, (float) sr * 0.495f);
        q = std::max (0.05f, q);
        const float w = kTau * f / (float) sr, cw = std::cos (w), sw = std::sin (w);
        const float alpha = sw / (2.0f * q);
        const float A = std::pow (10.0f, gainDb / 40.0f);
        float B0 = 1, B1 = 0, B2 = 0, A0 = 1, A1 = 0, A2 = 0;
        switch (t)
        {
            case LP:   B0 = (1 - cw) * 0.5f; B1 = 1 - cw; B2 = B0; A0 = 1 + alpha; A1 = -2 * cw; A2 = 1 - alpha; break;
            case HP:   B0 = (1 + cw) * 0.5f; B1 = -(1 + cw); B2 = B0; A0 = 1 + alpha; A1 = -2 * cw; A2 = 1 - alpha; break;
            case BP:   B0 = alpha; B1 = 0; B2 = -alpha; A0 = 1 + alpha; A1 = -2 * cw; A2 = 1 - alpha; break;
            case Notch:B0 = 1; B1 = -2 * cw; B2 = 1; A0 = 1 + alpha; A1 = -2 * cw; A2 = 1 - alpha; break;
            case Peak: B0 = 1 + alpha * A; B1 = -2 * cw; B2 = 1 - alpha * A; A0 = 1 + alpha / A; A1 = -2 * cw; A2 = 1 - alpha / A; break;
            case LowShelf:
            {
                const float s = 2 * std::sqrt (A) * alpha;
                B0 = A * ((A + 1) - (A - 1) * cw + s); B1 = 2 * A * ((A - 1) - (A + 1) * cw); B2 = A * ((A + 1) - (A - 1) * cw - s);
                A0 = (A + 1) + (A - 1) * cw + s; A1 = -2 * ((A - 1) + (A + 1) * cw); A2 = (A + 1) + (A - 1) * cw - s; break;
            }
            case HighShelf:
            {
                const float s = 2 * std::sqrt (A) * alpha;
                B0 = A * ((A + 1) + (A - 1) * cw + s); B1 = -2 * A * ((A - 1) + (A + 1) * cw); B2 = A * ((A + 1) + (A - 1) * cw - s);
                A0 = (A + 1) - (A - 1) * cw + s; A1 = 2 * ((A - 1) - (A + 1) * cw); A2 = (A + 1) - (A - 1) * cw - s; break;
            }
        }
        b0 = B0 / A0; b1 = B1 / A0; b2 = B2 / A0; a1 = A1 / A0; a2 = A2 / A0;
    }
    inline float process (float x)
    {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
    void reset() { z1 = z2 = 0; }
};

// 4-point cubic Hermite
inline float hermite (float xm1, float x0, float x1, float x2, float t)
{
    const float c1 = 0.5f * (x1 - xm1);
    const float c2 = xm1 - 2.5f * x0 + 2.0f * x1 - 0.5f * x2;
    const float c3 = 0.5f * (x2 - xm1) + 1.5f * (x0 - x1);
    return ((c3 * t + c2) * t + c1) * t + x0;
}

// Mono circular delay line with fractional read (power-of-two size)
struct DelayLine
{
    std::vector<float> buf;
    uint32_t mask = 0, w = 0;
    void prepare (size_t minSize)
    {
        size_t n = 1; while (n < minSize + 4) n <<= 1;
        buf.assign (n, 0.0f); mask = (uint32_t) n - 1; w = 0;
    }
    void clear() { std::fill (buf.begin(), buf.end(), 0.0f); }
    inline void push (float x) { buf[w] = x; w = (w + 1) & mask; }
    // delay in samples (>=1)
    inline float read (float d) const
    {
        const float pos = (float) w - d;
        const float fl = std::floor (pos);
        const float t = pos - fl;
        const int32_t i = (int32_t) fl;
        auto at = [&] (int32_t k) { return buf[(uint32_t) k & mask]; };
        return hermite (at (i - 1), at (i), at (i + 1), at (i + 2), t);
    }
    inline float readInt (uint32_t d) const { return buf[(w - d) & mask]; }
    size_t size() const { return buf.size(); }
};

// Soft saturators
inline float softClip (float x) { return std::tanh (x); }
inline float asymSat (float x, float bias) { return std::tanh (x + bias) - std::tanh (bias); }
} // namespace pf
