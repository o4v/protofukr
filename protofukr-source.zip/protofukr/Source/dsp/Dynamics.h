#pragma once
// protofukr — DYNAMICS: multi-character transient shaper + compressor.
#include "Common.h"
#include <atomic>

namespace pf
{
class TransientShaper
{
public:
    enum Mode { Off = 0, Sharp, Fat, Balanced, Punch, Snap, Smack, NumModes };
    struct Params { int mode = Off; float attack = 0.0f; float sustain = 0.0f; float focus = 1.0f; /* 0..1 band focus amount */ };

    void prepare (double sampleRate) { sr = sampleRate; lastMode = -1; for (auto& s : split) s.reset(); }

    void process (float* L, float* R, int n, const Params& p)
    {
        if (p.mode == Off) return;
        if (p.mode != lastMode) configure (p.mode);
        const bool stereo = R != nullptr;
        const float atkAmt = p.attack, susAmt = p.sustain - (p.mode == Punch ? 0.3f : 0.0f) + (p.mode == Fat ? 0.15f : 0.0f);
        for (int i = 0; i < n; ++i)
        {
            const float m = stereo ? 0.5f * (L[i] + R[i]) : L[i];
            const float det = std::abs (bandDetect.process (m)) + 1.0e-6f;
            const float f = fastE.process (det), s = slowE.process (det);
            const float sr1 = susSlow.process (det), sr2 = susFast.process (det);
            const float att = clampf (20.0f * std::log10 ((f + 1.0e-6f) / (s + 1.0e-6f)), 0.0f, 24.0f);
            const float sus = clampf (20.0f * std::log10 ((sr1 + 1.0e-6f) / (sr2 + 1.0e-6f)), 0.0f, 24.0f);
            const float gDb = clampf (atkAmt * att * atkScale + susAmt * sus * 0.7f, -15.0f, 12.0f);
            const float g = dbToGain (gDb);
            for (int c = 0; c < (stereo ? 2 : 1); ++c)
            {
                float* x = c == 0 ? L : R;
                const float lp = split[c].lp (x[i]);
                float band, rest;
                if (bandMode < 0)      { band = lp; rest = x[i] - lp; }       // low focus
                else if (bandMode > 0) { band = x[i] - lp; rest = lp; }       // high focus
                else                   { band = x[i]; rest = 0.0f; }
                const float bandW = (bandMode == 0) ? 1.0f : p.focus;
                float y = rest + band * (1.0f + (g - 1.0f) * bandW);
                if (p.mode == Smack || p.mode == Fat) y = std::tanh (y * (p.mode == Smack ? 1.6f : 1.25f)) / (p.mode == Smack ? 1.25f : 1.1f);
                x[i] = y;
            }
        }
    }

private:
    void configure (int mode)
    {
        lastMode = mode;
        float fa = 0.5f, sa = 20.0f; bandMode = 0; float splitHz = 1000.0f; atkScale = 0.8f;
        switch (mode)
        {
            case Sharp:    fa = 0.1f;  sa = 10.0f; bandMode = +1; splitHz = 1500.0f; atkScale = 1.0f; break;
            case Snap:     fa = 0.05f; sa = 4.0f;  bandMode = +1; splitHz = 3000.0f; atkScale = 1.2f; break;
            case Fat:      fa = 2.0f;  sa = 35.0f; bandMode = -1; splitHz = 250.0f;  atkScale = 0.9f; break;
            case Balanced: fa = 0.5f;  sa = 20.0f; bandMode = 0; break;
            case Punch:    fa = 1.0f;  sa = 15.0f; bandMode = 0; atkScale = 1.0f; break;
            case Smack:    fa = 0.3f;  sa = 12.0f; bandMode = 0; atkScale = 1.1f; break;
            default: break;
        }
        fastE.prepare (sr, fa, 60.0f); slowE.prepare (sr, sa, 60.0f);
        susSlow.prepare (sr, 5.0f, 350.0f); susFast.prepare (sr, 5.0f, 35.0f);
        split[0].setLP (sr, splitHz); split[1].setLP (sr, splitHz);
        if (bandMode > 0) bandDetect.set (Biquad::HP, sr, splitHz, 0.707f);
        else if (bandMode < 0) bandDetect.set (Biquad::LP, sr, splitHz * 1.5f, 0.707f);
        else bandDetect.set (Biquad::HP, sr, 30.0f, 0.707f);
    }

    double sr = 44100.0;
    EnvFollow fastE, slowE, susSlow, susFast;
    OnePole split[2];
    Biquad bandDetect;
    int lastMode = -1, bandMode = 0;
    float atkScale = 0.8f;
};

class Compressor
{
public:
    enum Style { CleanVCA = 0, Opto, FET, Glue, Brick, Pump, NumStyles };
    struct Params
    {
        bool on = false; int style = CleanVCA;
        float thresholdDb = -18.0f, ratio = 4.0f, attackMs = 10.0f, releaseMs = 120.0f, kneeDb = 6.0f, makeupDb = 0.0f, mix = 1.0f;
    };

    void prepare (double sampleRate) { sr = sampleRate; envDb = 0; rms = 0; scHP.set (Biquad::HP, sr, 90.0f, 0.707f); gr.store (0.0f); }

    void process (float* L, float* R, int n, const Params& p)
    {
        if (! p.on) { gr.store (0.0f); return; }
        const bool stereo = R != nullptr;
        const float atk = std::exp (-1.0f / (float) (sr * std::max (0.02f, p.attackMs * (p.style == FET ? 0.25f : 1.0f)) * 0.001));
        const float relBase = p.releaseMs * (p.style == Pump ? 2.5f : 1.0f);
        const float ratio = (p.style == Brick) ? 100.0f : std::max (1.0f, p.ratio);
        const float knee = std::max (0.0f, p.style == Brick ? 0.5f : p.kneeDb);
        const float makeup = dbToGain (p.makeupDb);
        const float rmsCoef = std::exp (-1.0f / (float) (sr * 0.015));
        float maxGr = 0.0f;

        for (int i = 0; i < n; ++i)
        {
            float det = std::max (std::abs (L[i]), stereo ? std::abs (R[i]) : 0.0f);
            if (p.style == Glue || p.style == Opto)
            {
                const float m = stereo ? 0.5f * (L[i] + R[i]) : L[i];
                const float hp = p.style == Glue ? scHP.process (m) : m;
                rms = hp * hp + (rms - hp * hp) * rmsCoef;
                det = std::sqrt (rms) * 1.414f;
            }
            const float inDb = gainToDb (det);
            // gain computer with soft knee
            const float over = inDb - p.thresholdDb;
            float redDb = 0.0f;
            if (2.0f * over < -knee) redDb = 0.0f;
            else if (2.0f * std::abs (over) <= knee) { const float t = over + knee * 0.5f; redDb = (1.0f / ratio - 1.0f) * t * t / (2.0f * std::max (knee, 1.0e-3f)); }
            else redDb = (1.0f / ratio - 1.0f) * over;
            const float target = -redDb;                       // positive dB of reduction

            float relMs = relBase;
            if (p.style == Opto) relMs = relBase * (1.0f + envDb * 0.25f);      // program dependent: deeper GR → slower
            if (p.style == Glue) relMs = relBase * (envDb > 6.0f ? 1.6f : 0.8f);
            const float rel = std::exp (-1.0f / (float) (sr * std::max (1.0f, relMs) * 0.001));
            envDb = target > envDb ? target + (envDb - target) * atk : target + (envDb - target) * rel;
            maxGr = std::max (maxGr, envDb);

            const float g = dbToGain (-envDb) * makeup;
            for (int c = 0; c < (stereo ? 2 : 1); ++c)
            {
                float* x = c == 0 ? L : R;
                float y = x[i] * g;
                if (p.style == FET)   y = std::tanh (y * 1.3f) / 1.3f * 1.08f;
                if (p.style == Brick) y = clampf (std::tanh (y * 1.05f), -0.98f, 0.98f);
                x[i] = p.mix * y + (1.0f - p.mix) * x[i];
            }
        }
        gr.store (maxGr);
    }

    std::atomic<float> gr { 0.0f };

private:
    double sr = 44100.0;
    float envDb = 0.0f, rms = 0.0f;
    Biquad scHP;
};
} // namespace pf
