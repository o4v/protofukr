#pragma once
// protofukr — INSERT FX slot. Groovebox-style performance effects (in the spirit of the
// SP-404 / SP-202 effect banks): isolator, filters, lo-fi, vinyl & cassette sims, stutter,
// looper, downer, tape stop / back spin, delays, reverb, mod FX, slicer, ring mod, resonator…
// Every effect uses three macro controls A / B / C plus the slot's wet/dry balance.
// Each slot owns one 4-second stereo buffer that all time-based effects share (RAM-light).
#include "Common.h"
#include <juce_audio_basics/juce_audio_basics.h>

namespace pf
{
struct HostTime
{
    double bpm = 120.0;
    double ppq = 0.0;          // position at start of block (quarter notes)
    bool   playing = false;
};

struct Svf   // TPT state-variable filter
{
    float ic1 = 0, ic2 = 0, g = 0, k = 1, a1 = 0, a2 = 0, a3 = 0;
    void set (double sr, float hz, float q)
    {
        g = std::tan (kPi * clampf (hz, 10.0f, (float) sr * 0.47f) / (float) sr);
        k = 1.0f / std::max (0.3f, q);
        a1 = 1.0f / (1.0f + g * (g + k)); a2 = g * a1; a3 = g * a2;
    }
    inline void tick (float v0, float& lp, float& bp, float& hp)
    {
        const float v3 = v0 - ic2;
        const float v1 = a1 * ic1 + a2 * v3;
        const float v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2.0f * v1 - ic1; ic2 = 2.0f * v2 - ic2;
        lp = v2; bp = v1; hp = v0 - k * v1 - v2;
    }
    void reset() { ic1 = ic2 = 0; }
};

class InsertFX
{
public:
    enum Type
    {
        Off = 0, Isolator, FilterDrive, SuperFilter, LoFi, VinylSimA, VinylSimB, CassetteSim, Stutter, Looper,
        Downer, TapeStop, SyncDelay, TapeEcho, Reverb, Chorus, Flanger, Phaser, Slicer, TremoloPan,
        RingMod, Resonator, AutoWah, Crusher, Overdrive, Distortion, PitchShift, NumTypes
    };

    static const char* typeName (int t)
    {
        static const char* n[] = { "Off", "Isolator", "Filter+Drive", "Super Filter", "Lo-Fi", "Vinyl Sim A", "Vinyl Sim B",
                                   "Cassette Sim", "Stutter", "DJ Looper", "Downer", "Tape Stop / Spin", "Sync Delay",
                                   "Tape Echo", "Reverb", "Chorus", "Flanger", "Phaser", "Slicer", "Tremolo / Pan",
                                   "Ring Mod", "Resonator", "Auto Wah", "Crusher", "Overdrive", "Distortion", "Pitch Shift" };
        return (t >= 0 && t < NumTypes) ? n[t] : "?";
    }

    // Labels for the A / B / C knobs of each effect
    static void labels (int t, const char*& a, const char*& b, const char*& c)
    {
        switch (t)
        {
            case Isolator:    a = "LOW";    b = "MID";     c = "HIGH";     break;
            case FilterDrive: a = "CUTOFF"; b = "RESO";    c = "DRIVE";    break;
            case SuperFilter: a = "CUTOFF"; b = "RATE";    c = "DEPTH";    break;
            case LoFi:        a = "RATE";   b = "BITS";    c = "TONE";     break;
            case VinylSimA:   a = "COMP";   b = "NOISE";   c = "WOW";      break;
            case VinylSimB:   a = "FREQ";   b = "NOISE";   c = "WOW";      break;
            case CassetteSim: a = "AGE";    b = "HISS";    c = "WOBBLE";   break;
            case Stutter:     a = "LENGTH"; b = "CHANCE";  c = "GATE";     break;
            case Looper:      a = "LENGTH"; b = "SPEED";   c = "HOLD";     break;
            case Downer:      a = "DEPTH";  b = "GLIDE";   c = "FILTER";   break;
            case TapeStop:    a = "TIME";   b = "TRIGGER"; c = "SPIN";     break;
            case SyncDelay:   a = "TIME";   b = "FEEDBK";  c = "LEVEL";    break;
            case TapeEcho:    a = "TIME";   b = "FEEDBK";  c = "TONE";     break;
            case Reverb:      a = "SIZE";   b = "DAMP";    c = "LEVEL";    break;
            case Chorus:      a = "MODE";   b = "DEPTH";   c = "LEVEL";    break;
            case Flanger:     a = "RATE";   b = "DEPTH";   c = "FEEDBK";   break;
            case Phaser:      a = "RATE";   b = "DEPTH";   c = "FEEDBK";   break;
            case Slicer:      a = "PATTERN";b = "DIV";     c = "DEPTH";    break;
            case TremoloPan:  a = "RATE";   b = "DEPTH";   c = "TRM/PAN";  break;
            case RingMod:     a = "FREQ";   b = "SWEEP";   c = "SHAPE";    break;
            case Resonator:   a = "NOTE";   b = "DECAY";   c = "BRIGHT";   break;
            case AutoWah:     a = "SENS";   b = "FREQ";    c = "RESO";     break;
            case Crusher:     a = "BITS";   b = "RATE";    c = "DRIVE";    break;
            case Overdrive:   a = "DRIVE";  b = "TONE";    c = "LEVEL";    break;
            case Distortion:  a = "DRIVE";  b = "TONE";    c = "LEVEL";    break;
            case PitchShift:  a = "SEMI";   b = "FINE";    c = "GRAIN";    break;
            default:          a = "A";      b = "B";       c = "C";        break;
        }
    }

    struct Params { int type = Off; bool on = false; float a = 0.5f, b = 0.5f, c = 0.5f, mix = 1.0f; };

    void prepare (double sampleRate, uint32_t seed)
    {
        sr = sampleRate;
        rng = Rng (seed);
        for (int c = 0; c < 2; ++c)
        {
            buf[c].prepare ((size_t) (sr * 4.0));
            echo[c].prepare ((size_t) (sr * 2.5));
            mod[c].prepare ((size_t) (sr * 0.12));
            for (auto& s : svf[c]) s.reset();
            for (auto& o : op[c]) o.reset();
            for (auto& ap : allp[c]) ap = 0.0f;
            held[c] = 0; shPhase[c] = 1;
            pink[c] = 0; crackle[c] = 0; fb[c] = 0;
        }
        verb.setSampleRate (sr);
        sa.prepare (sr, 15.0f); sb.prepare (sr, 15.0f); sc.prepare (sr, 15.0f); smix.prepare (sr, 15.0f);
        absPos = 0; lastType = -1;
        reset();
    }

    void reset()
    {
        for (int c = 0; c < 2; ++c) { buf[c].clear(); mod[c].clear(); echo[c].clear(); for (auto& s : svf[c]) s.reset(); fb[c] = 0; for (auto& a : allp[c]) a = 0; }
        verb.reset();
        stutterActive = false; loopActive = false; stopActive = false; stopSpeed = 1.0; readPos = 0;
        lfo = 0; lfo2 = 0; env.reset(); pitchPhase = 0; downSemis = 0;
    }

    void process (float* L, float* R, int n, const Params& p, const HostTime& ht)
    {
        if (! p.on || p.type == Off) { feedHistory (L, R, n); return; }
        if (p.type != lastType)
        {
            if (lastType >= 0) reset();
            lastType = p.type;
            sa.reset (p.a); sb.reset (p.b); sc.reset (p.c); smix.reset (p.mix);
        }
        sa.set (p.a); sb.set (p.b); sc.set (p.c); smix.set (p.mix);
        const bool stereo = R != nullptr;
        const double spb = 60.0 / std::max (20.0, ht.bpm) * sr;        // samples per beat
        double ppq = ht.playing ? ht.ppq : freePpq;

        for (int i = 0; i < n; ++i)
        {
            const float A = sa.next(), B = sb.next(), C = sc.next(), MIX = smix.next();
            const float inL = L[i], inR = stereo ? R[i] : inL;
            float oL = inL, oR = inR;
            buf[0].push (inL); buf[1].push (inR);
            ++absPos;

            switch (p.type)
            {
                case Isolator:
                {
                    const float gl = isoGain (A), gm = isoGain (B), gh = isoGain (C);
                    for (int c = 0; c < 2; ++c)
                    {
                        const float x = c ? inR : inL;
                        op[c][0].setLP (sr, 250.0f); op[c][1].setLP (sr, 2500.0f);
                        const float lo = op[c][0].lp (x), hiLp = op[c][1].lp (x);
                        const float hi = x - hiLp, mid = hiLp - lo;
                        (c ? oR : oL) = lo * gl + mid * gm + hi * gh;
                    }
                    break;
                }
                case FilterDrive:
                {
                    const float hz = 30.0f * std::pow (600.0f, A), q = 0.5f + B * B * 14.0f, drv = 1.0f + C * 12.0f;
                    for (int c = 0; c < 2; ++c)
                    {
                        float lp, bp, hp; svf[c][0].set (sr, hz, q);
                        svf[c][0].tick (std::tanh ((c ? inR : inL) * drv) / std::sqrt (drv), lp, bp, hp);
                        (c ? oR : oL) = lp;
                    }
                    break;
                }
                case SuperFilter:
                {
                    static const double divs[] = { 16.0, 8.0, 4.0, 2.0, 1.0, 0.5, 0.25 };
                    const double d = divs[(int) clampf (B * 6.99f, 0.0f, 6.0f)];
                    const float ph = (float) std::fmod ((ppq + (double) i / spb) / d, 1.0);
                    const float lf = 0.5f - 0.5f * std::cos (kTau * ph);
                    const float hz = 40.0f * std::pow (400.0f, clampf (A + (lf - 0.5f) * C, 0.0f, 1.0f));
                    for (int c = 0; c < 2; ++c)
                    {
                        float lp, bp, hp; svf[c][0].set (sr, hz, 2.2f);
                        svf[c][0].tick (c ? inR : inL, lp, bp, hp); svf[c][1].set (sr, hz, 0.8f);
                        float lp2, bp2, hp2; svf[c][1].tick (lp, lp2, bp2, hp2);
                        (c ? oR : oL) = lp2 * 0.6f;
                    }
                    break;
                }
                case LoFi: case Crusher:
                {
                    const float rate = p.type == LoFi ? 1500.0f * std::pow (30.0f, A) : 800.0f * std::pow (55.0f, B);
                    const float bits = p.type == LoFi ? 4.0f + B * 12.0f : 1.0f + A * 15.0f;
                    const float levels = std::pow (2.0f, bits - 1.0f);
                    const float drive = p.type == Crusher ? 1.0f + C * 8.0f : 1.2f;
                    for (int c = 0; c < 2; ++c)
                    {
                        shPhase[c] += rate / (float) sr;
                        float x = std::tanh ((c ? inR : inL) * drive) / (p.type == Crusher ? std::sqrt (drive) : 1.0f);
                        if (shPhase[c] >= 1.0f) { shPhase[c] -= std::floor (shPhase[c]); held[c] = std::round (x * levels) / levels; }
                        float y = held[c];
                        if (p.type == LoFi) { op[c][0].setLP (sr, 800.0f * std::pow (25.0f, C)); y = op[c][0].lp (y); }
                        (c ? oR : oL) = y;
                    }
                    break;
                }
                case VinylSimA: case VinylSimB: case CassetteSim:
                {
                    // wow via short modulated delay
                    lfo += (p.type == CassetteSim ? 0.9f : 0.55f) / (float) sr; if (lfo > 1) lfo -= 1;
                    lfo2 += 6.5f / (float) sr; if (lfo2 > 1) lfo2 -= 1;
                    const float wowAmt = (p.type == CassetteSim) ? C : C * 0.7f;
                    const float d = 2.0f + wowAmt * (float) sr * 0.0025f * (1.0f + std::sin (kTau * lfo))
                                  + (p.type == CassetteSim ? wowAmt * (float) sr * 0.0002f * (1.0f + std::sin (kTau * lfo2)) : 0.0f);
                    float lpHz = p.type == VinylSimB ? 2500.0f * std::pow (7.0f, A) : (p.type == CassetteSim ? 14000.0f - A * 10000.0f : 11000.0f);
                    const float noiseAmt = B * (p.type == CassetteSim ? 0.04f : 0.03f);
                    const float compAmt = p.type == VinylSimA ? A : 0.3f;
                    const bool pop = rng.uni() < (p.type == CassetteSim ? 0.0f : 0.00008f + B * 0.0004f);
                    for (int c = 0; c < 2; ++c)
                    {
                        const float x = c ? inR : inL;
                        mod[c].push (x);
                        float y = mod[c].read (d);
                        op[c][0].setLP (sr, lpHz); y = op[c][0].lp (y);
                        op[c][1].setLP (sr, p.type == CassetteSim ? 60.0f : 35.0f); y = y - op[c][1].lp (y);
                        y = std::tanh (y * (1.0f + compAmt * 4.0f)) / (1.0f + compAmt * 1.5f);
                        const float w = rng.gauss() * 0.3f;
                        pink[c] = 0.97f * pink[c] + 0.03f * w;
                        float nz = (p.type == CassetteSim ? w * 0.6f + pink[c] * 3.0f : pink[c] * 4.0f) * noiseAmt;
                        if (pop) crackle[c] = (rng.bi() > 0 ? 1.0f : -1.0f) * (0.2f + 0.5f * B);
                        nz += crackle[c]; crackle[c] *= 0.55f;
                        (c ? oR : oL) = y + nz;
                    }
                    break;
                }
                case Stutter:
                {
                    static const double divs[] = { 2.0, 1.0, 0.5, 0.25, 0.125, 1.0 / 3.0, 1.0 / 6.0 };
                    const double d = divs[(int) clampf (A * 6.99f, 0.0f, 6.0f)];
                    const double pos = (ppq + (double) i / spb) / d;
                    const int64_t slot = (int64_t) std::floor (pos);
                    const int sliceLen = std::max (16, (int) (d * spb));
                    if (slot != lastSlot)
                    {
                        lastSlot = slot;
                        if (rng.uni() < B && (B > 0.995f || stutterHasCapture))
                        {
                            if (! stutterActive) { capStart = absPos; stutterHasCapture = true; }
                            if (B <= 0.995f && rng.uni() < 0.35f) capStart = absPos;   // occasional fresh grab
                            stutterActive = true;
                        }
                        else { stutterActive = false; capStart = absPos; stutterHasCapture = true; }
                        repPos = 0;
                    }
                    if (stutterActive)
                    {
                        const float gateLen = 0.15f + 0.85f * C;
                        const int64_t src = capStart + (repPos % sliceLen);
                        const uint32_t dly = (uint32_t) std::max<int64_t> (1, absPos - src);
                        float g = ((float) (repPos % sliceLen) < gateLen * (float) sliceLen) ? 1.0f : 0.0f;
                        const int edge = repPos % sliceLen; if (edge < 32) g *= (float) edge / 32.0f;
                        if (dly < buf[0].size() - 2) { oL = buf[0].readInt (dly) * g; oR = buf[1].readInt (dly) * g; }
                        ++repPos;
                    }
                    break;
                }
                case Looper:
                {
                    const bool hold = C > 0.5f;
                    static const double lens[] = { 0.125, 0.25, 0.5, 1.0, 2.0, 4.0 };
                    const int len = std::max (64, (int) (lens[(int) clampf (A * 5.99f, 0.0f, 5.0f)] * spb));
                    if (hold && ! loopActive) { loopActive = true; loopStart = absPos - len; readPos = 0.0; }
                    if (! hold) loopActive = false;
                    if (loopActive)
                    {
                        const double speed = (B - 0.5) * 4.0;      // -2x .. +2x
                        readPos += speed;
                        while (readPos >= len) readPos -= len;
                        while (readPos < 0) readPos += len;
                        const double src = (double) loopStart + readPos;
                        const float d = (float) ((double) absPos - src);
                        float g = 1.0f; const double e = std::min (readPos, (double) len - readPos);
                        if (e < 96.0) g = (float) (e / 96.0);
                        if (d < (float) buf[0].size() - 4) { oL = buf[0].read (d) * g; oR = buf[1].read (d) * g; }
                    }
                    break;
                }
                case Downer: case PitchShift:
                {
                    float semis;
                    if (p.type == Downer)
                    {
                        const float glideCoef = std::exp (-1.0f / (float) (sr * (0.02f + B * 3.0f)));
                        downSemis = -A * 12.0f + (downSemis + A * 12.0f) * glideCoef;
                        semis = downSemis;
                    }
                    else semis = std::round ((A - 0.5f) * 24.0f) + (B - 0.5f);
                    const float ratio = std::exp2 (semis / 12.0f);
                    const float win = (p.type == PitchShift ? 0.02f + C * 0.1f : 0.06f) * (float) sr;
                    pitchPhase += (1.0f - ratio) / win; pitchPhase -= std::floor (pitchPhase);
                    for (int c = 0; c < 2; ++c)
                    {
                        const float x = c ? inR : inL;
                        mod[c].push (x);
                        const float p1 = pitchPhase, p2 = std::fmod (pitchPhase + 0.5f, 1.0f);
                        const float y = mod[c].read (2.0f + p1 * win) * std::sin (kPi * p1) + mod[c].read (2.0f + p2 * win) * std::sin (kPi * p2);
                        float out = y;
                        if (p.type == Downer) { op[c][0].setLP (sr, 400.0f + (1.0f - C) * 16000.0f); out = op[c][0].lp (out); }
                        (c ? oR : oL) = out;
                    }
                    break;
                }
                case TapeStop:
                {
                    const bool trig = B > 0.5f; const bool spin = C > 0.5f;
                    if (trig && ! stopActive) { stopActive = true; stopSpeed = 1.0; readPos = 0.0; stopStart = absPos; }
                    if (! trig) stopActive = false;
                    if (stopActive)
                    {
                        const double t = 0.05 + A * 3.0;
                        if (spin) stopSpeed = stopSpeed - (stopSpeed - (-2.5)) * (1.0 - std::exp (-1.0 / (sr * t * 0.25)));
                        else stopSpeed = std::max (0.0, stopSpeed - 1.0 / (sr * t));
                        readPos += stopSpeed;
                        const double src = (double) stopStart + readPos;
                        const float d = (float) std::max (2.0, (double) absPos - src);
                        const float g = spin ? 1.0f : (float) std::min (1.0, stopSpeed * 4.0);
                        if (d < (float) buf[0].size() - 4) { oL = buf[0].read (d) * g; oR = buf[1].read (d) * g; }
                        else { oL = oR = 0.0f; }
                    }
                    break;
                }
                case SyncDelay: case TapeEcho:
                {
                    float d;
                    if (p.type == SyncDelay)
                    {
                        static const double divs[] = { 0.25, 0.375, 1.0 / 3.0, 0.5, 0.75, 2.0 / 3.0, 1.0, 1.5, 2.0, 4.0 };
                        d = (float) (divs[(int) clampf (A * 9.99f, 0.0f, 9.0f)] * spb);
                    }
                    else
                    {
                        lfo += 0.7f / (float) sr; if (lfo > 1) lfo -= 1;
                        d = (0.05f + A * 0.95f) * (float) sr * (1.0f + 0.004f * C * std::sin (kTau * lfo));
                    }
                    d = clampf (d, 2.0f, (float) echo[0].size() - 8.0f);
                    const float fbk = p.type == SyncDelay ? B * 0.95f : B * 1.08f;
                    for (int c = 0; c < 2; ++c)
                    {
                        float tap = echo[c].read (d);
                        if (p.type == TapeEcho)
                        {
                            op[c][0].setLP (sr, 1500.0f + (1.0f - C) * 9000.0f); tap = op[c][0].lp (tap);
                            op[c][1].setLP (sr, 120.0f); tap = tap - op[c][1].lp (tap);
                            tap = std::tanh (tap);
                        }
                        const float x = c ? inR : inL;
                        echo[c].push (sanitize (x + tap * fbk));
                        (c ? oR : oL) = x + tap * (p.type == SyncDelay ? C * 1.4f : 1.0f);
                    }
                    break;
                }
                case Reverb:
                {
                    if (i == 0)
                    {
                        juce::Reverb::Parameters rp; rp.roomSize = 0.3f + 0.7f * A; rp.damping = B; rp.wetLevel = C * 0.5f; rp.dryLevel = 1.0f - 0.4f * C; rp.width = 1.0f;
                        verb.setParameters (rp);
                    }
                    verbL[i & 63] = inL; verbR[i & 63] = inR;
                    if ((i & 63) == 63 || i == n - 1)
                    {
                        const int cnt = (i & 63) + 1;
                        verb.processStereo (verbL, verbR, cnt);
                        for (int k = 0; k < cnt; ++k) { L[i - cnt + 1 + k] = mixOut (L[i - cnt + 1 + k], verbL[k], MIX); if (stereo) R[i - cnt + 1 + k] = mixOut (R[i - cnt + 1 + k], verbR[k], MIX); }
                    }
                    continue;    // written in blocks of 64
                }
                case Chorus: case Flanger:
                {
                    float rate, base, depth, fbk = 0.0f;
                    if (p.type == Chorus)
                    {
                        const int mode = (int) clampf (A * 2.99f, 0.0f, 2.0f);
                        rate = mode == 0 ? 0.5f : (mode == 1 ? 0.83f : 9.8f);
                        base = 0.0035f * (float) sr; depth = (mode == 2 ? 0.0003f : 0.0019f) * (float) sr * (0.3f + B);
                    }
                    else { rate = 0.03f * std::pow (150.0f, A); base = 0.0012f * (float) sr; depth = 0.0035f * (float) sr * B; fbk = (C - 0.5f) * 1.9f; }
                    lfo += rate / (float) sr; if (lfo > 1) lfo -= 1;
                    for (int c = 0; c < 2; ++c)
                    {
                        const float l = std::sin (kTau * (lfo + (c ? 0.5f : 0.0f)));
                        const float x = (c ? inR : inL);
                        mod[c].push (x + fb[c]);
                        const float y = mod[c].read (base + depth * (0.5f + 0.5f * l));
                        fb[c] = std::tanh (y * fbk);
                        (c ? oR : oL) = p.type == Chorus ? x + y * (0.3f + 1.2f * C) : 0.5f * (x + y) * 1.4f;
                    }
                    break;
                }
                case Phaser:
                {
                    lfo += 0.03f * std::pow (200.0f, A) / (float) sr; if (lfo > 1) lfo -= 1;
                    for (int c = 0; c < 2; ++c)
                    {
                        const float l = 0.5f + 0.5f * std::sin (kTau * (lfo + (c ? 0.25f : 0.0f)));
                        const float hz = 200.0f * std::pow (20.0f, l * B);
                        const float t = std::tan (kPi * std::min (hz, (float) sr * 0.45f) / (float) sr);
                        const float coef = (t - 1.0f) / (t + 1.0f);
                        float y = (c ? inR : inL) + fb[c] * (C * 0.9f);
                        for (int s = 0; s < 6; ++s)
                        {
                            const float o = coef * y + allp[c][s];
                            allp[c][s] = y - coef * o;
                            y = o;
                        }
                        fb[c] = sanitize (y);
                        (c ? oR : oL) = 0.5f * ((c ? inR : inL) + y) * 1.4f;
                    }
                    break;
                }
                case Slicer: case TremoloPan:
                {
                    float g = 1.0f, pan = 0.0f;
                    if (p.type == Slicer)
                    {
                        static const uint16_t pats[8] = { 0xAAAA, 0xEEEE, 0x9249, 0xF0F0, 0xB6DB, 0xCCCC, 0x8888, 0xDB6D };
                        static const double divs[] = { 0.5, 0.25, 0.125 };
                        const double d = divs[(int) clampf (B * 2.99f, 0.0f, 2.0f)];
                        const double pos = (ppq + (double) i / spb) / d;
                        const int step = (int) ((int64_t) std::floor (pos) & 15);
                        const bool onStep = (pats[(int) clampf (A * 7.99f, 0.0f, 7.0f)] >> (15 - step)) & 1;
                        const float frac = (float) (pos - std::floor (pos));
                        float gate = onStep ? (frac < 0.85f ? 1.0f : (1.0f - frac) / 0.15f) : 0.0f;
                        gateSm = gate + (gateSm - gate) * 0.99f;
                        g = 1.0f - C * (1.0f - gateSm);
                    }
                    else
                    {
                        static const double divs[] = { 4.0, 2.0, 1.0, 0.5, 0.25, 0.125, 1.0 / 3.0, 1.0 / 6.0 };
                        const double d = divs[(int) clampf (A * 7.99f, 0.0f, 7.0f)];
                        const float ph = (float) std::fmod ((ppq + (double) i / spb) / d, 1.0);
                        const float l = std::sin (kTau * ph);
                        if (C < 0.5f) g = 1.0f - B * (0.5f - 0.5f * l);
                        else pan = l * B;
                    }
                    oL = inL * g * (1.0f - std::max (0.0f, pan));
                    oR = inR * g * (1.0f + std::min (0.0f, pan));
                    break;
                }
                case RingMod:
                {
                    const float e = env.process (0.5f * (inL + inR));
                    const float hz = 20.0f * std::pow (200.0f, A) * (1.0f + B * 4.0f * clampf (e * 3.0f, 0.0f, 1.0f));
                    lfo += hz / (float) sr; lfo -= std::floor (lfo);
                    const float s = std::sin (kTau * lfo);
                    const float carrier = (1.0f - C) * s + C * (s >= 0 ? 1.0f : -1.0f);
                    oL = inL * carrier; oR = inR * carrier;
                    break;
                }
                case Resonator:
                {
                    const float note = 36.0f + A * 48.0f;
                    for (int c = 0; c < 2; ++c)
                    {
                        const float hz = 440.0f * std::exp2 ((note - 69.0f) / 12.0f) * (c ? 1.003f : 1.0f);
                        const float d = (float) sr / hz;
                        float tap = mod[c].read (std::max (2.0f, d));
                        op[c][0].setLP (sr, 1000.0f + C * 15000.0f); tap = op[c][0].lp (tap);
                        mod[c].push ((c ? inR : inL) * 0.3f + tap * (0.7f + B * 0.295f));
                        (c ? oR : oL) = tap;
                    }
                    break;
                }
                case AutoWah:
                {
                    env.prepare (sr, 2.0f, 120.0f);
                    const float e = clampf (env.process (0.5f * (inL + inR)) * (1.0f + A * 20.0f), 0.0f, 1.0f);
                    const float hz = 200.0f * std::pow (15.0f, clampf (B + e * 0.8f, 0.0f, 1.0f));
                    for (int c = 0; c < 2; ++c)
                    {
                        float lp, bp, hp; svf[c][0].set (sr, hz, 1.0f + C * 10.0f);
                        svf[c][0].tick (c ? inR : inL, lp, bp, hp);
                        (c ? oR : oL) = bp * 1.5f + lp * 0.3f;
                    }
                    break;
                }
                case Overdrive: case Distortion:
                {
                    const float drv = 1.0f + A * (p.type == Distortion ? 60.0f : 15.0f);
                    for (int c = 0; c < 2; ++c)
                    {
                        float x = (c ? inR : inL) * drv;
                        float y = p.type == Distortion ? clampf (x, -1.0f, 1.0f) * 0.8f + 0.2f * std::tanh (x * 3.0f)
                                                       : asymSat (x, 0.25f);
                        op[c][0].setLP (sr, 1200.0f + B * 16000.0f); y = op[c][0].lp (y);
                        (c ? oR : oL) = y * (0.2f + C * 0.9f);
                    }
                    break;
                }
                default: break;
            }

            L[i] = mixOut (inL, sanitize (oL), MIX);
            if (stereo) R[i] = mixOut (inR, sanitize (oR), MIX);
        }
        freePpq += (double) n / spb;
    }

private:
    static inline float mixOut (float dry, float wet, float m) { return dry + (wet - dry) * m; }
    static inline float isoGain (float v)
    {
        if (v < 0.02f) return 0.0f;
        if (v < 0.8f) return dbToGain ((v - 0.8f) / 0.78f * 40.0f);
        return dbToGain ((v - 0.8f) / 0.2f * 6.0f);
    }

    void feedHistory (float* L, float* R, int n)
    {
        for (int i = 0; i < n; ++i) { buf[0].push (L[i]); buf[1].push (R ? R[i] : L[i]); ++absPos; }
    }

    double sr = 44100.0;
    DelayLine buf[2], mod[2], echo[2];
    Svf svf[2][2];
    OnePole op[2][2];
    float allp[2][6] {};
    float held[2] {}, shPhase[2] {}, pink[2] {}, crackle[2] {}, fb[2] {};
    juce::Reverb verb;
    float verbL[64] {}, verbR[64] {};
    Smooth sa, sb, sc, smix;
    EnvFollow env;
    Rng rng;
    int64_t absPos = 0, capStart = 0, loopStart = 0, stopStart = 0, lastSlot = -1, repPos = 0;
    bool stutterActive = false, stutterHasCapture = false, loopActive = false, stopActive = false;
    double readPos = 0.0, stopSpeed = 1.0, freePpq = 0.0;
    float lfo = 0, lfo2 = 0, pitchPhase = 0, downSemis = 0, gateSm = 0;
    int lastType = -1;
};
} // namespace pf
