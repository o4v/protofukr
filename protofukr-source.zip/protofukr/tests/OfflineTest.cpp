// protofukr offline test runner: renders audio through the real processor, checks for
// NaN/Inf/blow-ups, measures codec transparency / bandwidth / latency / CPU, and renders
// the editor (and the qaeru animation) to PNGs.
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "Presets.h"
#include <cstdio>

struct TestPlayHead : juce::AudioPlayHead
{
    double bpm = 120.0, ppq = 0.0; bool playing = true;
    juce::Optional<PositionInfo> getPosition() const override
    {
        PositionInfo p; p.setBpm (bpm); p.setPpqPosition (ppq); p.setIsPlaying (playing);
        p.setTimeSignature (TimeSignature { 4, 4 });
        return p;
    }
};

static constexpr double SR = 44100.0;
static constexpr int BS = 512;
static int failures = 0;
#define CHECK(cond, ...) do { if (! (cond)) { ++failures; std::printf ("  FAIL: " __VA_ARGS__); std::printf ("\n"); } } while (0)

// drums + chord bed, 8 s stereo
static juce::AudioBuffer<float> makeTestSignal (int len)
{
    juce::AudioBuffer<float> b (2, len); b.clear();
    juce::Random r (1);
    const double spb = SR * 0.5;      // 120 bpm
    for (int i = 0; i < len; ++i)
    {
        const double beat = (double) i / spb;
        const double inBeat = std::fmod (beat, 1.0) * spb / SR;          // seconds since beat
        const int bn = (int) beat;
        float s = 0;
        if (bn % 2 == 0) s += 0.8f * (float) std::sin (2 * juce::MathConstants<double>::pi * (50 + 120 * std::exp (-inBeat * 30)) * inBeat) * (float) std::exp (-inBeat * 8);
        else             s += 0.5f * (r.nextFloat() * 2 - 1) * (float) std::exp (-inBeat * 18);
        const double inEighth = std::fmod (beat * 2, 1.0) * spb * 0.5 / SR;
        s += 0.15f * (r.nextFloat() * 2 - 1) * (float) std::exp (-inEighth * 90);
        const double t = i / SR;
        float pad = 0;
        for (double f : { 220.0, 261.63, 329.63, 392.0 }) pad += (float) (std::fmod (t * f, 1.0) * 2 - 1);
        b.setSample (0, i, s + 0.05f * pad);
        b.setSample (1, i, s * 0.9f + 0.05f * pad * 0.8f);
    }
    return b;
}

struct RunResult { float peak = 0, rms = 0; bool finite = true; double cpuPct = 0; };

static RunResult run (ProtofukrProcessor& p, TestPlayHead& ph, const juce::AudioBuffer<float>& in, juce::AudioBuffer<float>* out = nullptr)
{
    RunResult rr;
    juce::AudioBuffer<float> blk (2, BS);
    juce::MidiBuffer midi;
    if (out) out->setSize (2, in.getNumSamples());
    ph.ppq = 0.0;
    const double t0 = juce::Time::getMillisecondCounterHiRes();
    double sq = 0;
    for (int pos = 0; pos + BS <= in.getNumSamples(); pos += BS)
    {
        for (int c = 0; c < 2; ++c) blk.copyFrom (c, 0, in, c, pos, BS);
        p.processBlock (blk, midi);
        for (int c = 0; c < 2; ++c)
        {
            const float* d = blk.getReadPointer (c);
            for (int i = 0; i < BS; ++i)
            {
                if (! std::isfinite (d[i])) rr.finite = false;
                rr.peak = std::max (rr.peak, std::abs (d[i]));
                sq += (double) d[i] * d[i];
            }
            if (out) out->copyFrom (c, pos, blk, c, 0, BS);
        }
        ph.ppq += BS / (SR * 0.5);
    }
    const double ms = juce::Time::getMillisecondCounterHiRes() - t0;
    rr.cpuPct = 100.0 * ms / (1000.0 * in.getNumSamples() / SR);
    rr.rms = (float) std::sqrt (sq / (2.0 * in.getNumSamples()));
    return rr;
}

static void writeWav (const juce::AudioBuffer<float>& b, const juce::File& f)
{
    f.deleteFile();
    juce::WavAudioFormat wav;
    std::unique_ptr<juce::AudioFormatWriter> w (wav.createWriterFor (new juce::FileOutputStream (f), SR, 2, 16, {}, 0));
    if (w) w->writeFromAudioSampleBuffer (b, 0, b.getNumSamples());
}

static float bandEnergyAbove (const juce::AudioBuffer<float>& b, float hz)
{
    juce::dsp::FFT fft (12);
    std::vector<float> w (8192);
    double above = 0, total = 0;
    for (int pos = 44100; pos + 4096 < b.getNumSamples(); pos += 4096)
    {
        std::fill (w.begin(), w.end(), 0.0f);
        for (int i = 0; i < 4096; ++i) w[(size_t) i] = b.getSample (0, pos + i) * (0.5f - 0.5f * std::cos (6.2831853f * i / 4095.0f));
        fft.performFrequencyOnlyForwardTransform (w.data());
        for (int k = 1; k < 2048; ++k)
        {
            const double e = (double) w[(size_t) k] * w[(size_t) k];
            total += e;
            if ((float) k * (float) SR / 4096.0f > hz) above += e;
        }
    }
    return (float) (above / std::max (1e-20, total));
}

static void resetAll (ProtofukrProcessor& p)
{
    p.applyPreset (0);
    p.prepareToPlay (SR, BS);
}

int main (int argc, char** argv)
{
    juce::ScopedJuceInitialiser_GUI gui;
    const juce::File outDir (argc > 1 ? argv[1] : "/tmp/pf_out");
    outDir.createDirectory();

    ProtofukrProcessor p;
    TestPlayHead ph;
    p.setPlayHead (&ph);
    p.setPlayConfigDetails (2, 2, SR, BS);
    p.prepareToPlay (SR, BS);
    const auto sig = makeTestSignal ((int) (SR * 8));
    juce::AudioBuffer<float> out;

    std::printf ("== parameters: %d (all host-automatable)\n", (int) p.getParameters().size());

    // ---------- 1. Init preset is transparent
    {
        resetAll (p);
        auto r = run (p, ph, sig, &out);
        double err = 0; int at = 0;
        for (int i = 0; i < out.getNumSamples() - BS; ++i) { const double e = std::abs (out.getSample (0, i) - sig.getSample (0, i)); if (e > err) { err = e; at = i; } }
        std::printf ("   worst at %d: in %.4f out %.4f (prev in %.4f)\n", at, sig.getSample (0, at), out.getSample (0, at), sig.getSample (0, juce::jmax (0, at - 1)));
        std::printf ("== init passthrough: max err %.6f, cpu %.2f%%\n", err, r.cpuPct);
        CHECK (err < 1e-4, "init preset not transparent (%f)", err);
    }

    // ---------- 2a. raw MDCT reconstruction (no meaningful quantisation)
    for (int fr : { 1, 2, 3, 4 })
    {
        pf::LofiCodec c; c.prepare (SR);
        pf::LofiCodec::Params cp; cp.type = pf::LofiCodec::AAC; cp.kbps = 1.0e7f; cp.targetSR = 44100; cp.frame = fr; cp.stereo = 0;
        juce::AudioBuffer<float> ref (2, sig.getNumSamples());
        for (int i = 0; i < ref.getNumSamples(); ++i)
        {
            const double t = i / SR;
            const float v = (float) (0.3 * std::sin (6.283 * 220 * t) + 0.2 * std::sin (6.283 * 1234 * t) * std::exp (-std::fmod (t, 0.5) * 8) + 0.1 * std::sin (6.283 * 9000 * t));
            ref.setSample (0, i, v); ref.setSample (1, i, v * 0.7f);
        }
        juce::AudioBuffer<float> b (ref);
        for (int pos = 0; pos + BS <= b.getNumSamples(); pos += BS) c.process (b.getWritePointer (0, pos), b.getWritePointer (1, pos), BS, cp);
        const int lat = c.latencyFor (cp);
        double se = 0, ss = 0, sxy = 0;
        for (int i = 44100; i < b.getNumSamples() - BS; ++i) { const double x = ref.getSample (0, i - lat), y = b.getSample (0, i); se += (x - y) * (x - y); ss += x * x; sxy += x * y; }
        std::printf ("== raw MDCT frame %d: latency %d, SNR %.1f dB, gain %.4f\n", fr, lat, 10 * std::log10 (ss / std::max (1e-30, se)), sxy / ss);
        CHECK (10 * std::log10 (ss / std::max (1e-30, se)) > 50.0, "MDCT reconstruction broken (frame %d)", fr);
    }

    // ---------- 2. codec quality vs bitrate (tonal + drum reference), and latency reporting
    {
        juce::AudioBuffer<float> ref (2, sig.getNumSamples());
        for (int i = 0; i < ref.getNumSamples(); ++i)
        {
            const double t = i / SR;
            const float v = (float) (0.3 * std::sin (6.283 * 220 * t) + 0.2 * std::sin (6.283 * 1234 * t) * std::exp (-std::fmod (t, 0.5) * 8)
                                     + 0.1 * std::sin (6.283 * 5000 * t) + 0.5 * sig.getSample (0, i) * (float) (std::fmod (t, 1.0) < 0.5));
            ref.setSample (0, i, juce::jlimit (-1.0f, 1.0f, v)); ref.setSample (1, i, juce::jlimit (-1.0f, 1.0f, v * 0.7f));
        }
        for (int type : { 3, 4, 5 })
        {
            std::printf ("== %-8s SNR by bitrate:", choices::codecType[type].toRawUTF8());
            for (float kb : { 32.0f, 64.0f, 128.0f, 192.0f, 320.0f })
            {
                pf::LofiCodec c; c.prepare (SR);
                pf::LofiCodec::Params cp; cp.type = type; cp.kbps = kb; cp.targetSR = 44100; cp.stereo = 1;
                juce::AudioBuffer<float> b (ref);
                for (int pos = 0; pos + BS <= b.getNumSamples(); pos += BS) c.process (b.getWritePointer (0, pos), b.getWritePointer (1, pos), BS, cp);
                const int lat = c.latencyFor (cp);
                double se = 0, ss = 0;
                for (int i = 44100; i < b.getNumSamples() - BS; ++i) { const double x = ref.getSample (0, i - lat), y = b.getSample (0, i); se += (x - y) * (x - y); ss += x * x; }
                const double snr = 10 * std::log10 (ss / std::max (1e-30, se));
                std::printf ("  %3.0fk %5.1fdB", kb, snr);
                if (kb == 320.0f && type != 5) CHECK (snr > 20.0, "codec %d at 320k SNR %.1f", type, snr);
            }
            std::printf ("\n");
        }
        resetAll (p);
        p.setParam (pid::lofiOn, 1); p.setParam (pid::codecType, 3); p.setParam (pid::codecSR, 22050);
        run (p, ph, sig, nullptr);
        juce::MessageManager::getInstance()->runDispatchLoopUntil (300);
        std::printf ("== reported latency (MP3 '08 @22.05k): %d samples = %.1f ms\n", p.getLatencySamples(), 1000.0 * p.getLatencySamples() / SR);
    }

    // ---------- 3. 2008 YouTube SQ preset: bandwidth must be limited (~ <11 kHz)
    {
        p.applyPreset (1);
        auto r = run (p, ph, sig, &out);
        const float above = bandEnergyAbove (out, 11500.0f), aboveIn = bandEnergyAbove (sig, 11500.0f);
        std::printf ("== YouTube '08 SQ: energy above 11.5k  in %.2e  out %.2e   peak %.2f  cpu %.1f%%\n", aboveIn, above, r.peak, r.cpuPct);
        CHECK (above < aboveIn * 0.01f, "YouTube SQ not band-limited");
        writeWav (out, outDir.getChildFile ("youtube08_sq.wav"));
    }
    writeWav (sig, outDir.getChildFile ("input.wav"));

    // ---------- 4. every factory preset
    std::printf ("== factory presets\n");
    for (int i = 0; i < p.getNumPrograms(); ++i)
    {
        p.applyPreset (i);
        p.prepareToPlay (SR, BS);
        auto r = run (p, ph, sig, &out);
        std::printf ("  %-34s peak %5.2f rms %.3f cpu %5.1f%% lat %d %s\n", p.getProgramName (i).toRawUTF8(), r.peak, r.rms, r.cpuPct, p.codecHop.load(), r.finite ? "" : "NON-FINITE");
        CHECK (r.finite && r.peak < 6.0f && r.rms > 1e-4f, "preset %d bad output", i);
        writeWav (out, outDir.getChildFile ("preset_" + juce::String (i).paddedLeft ('0', 2) + ".wav"));
    }

    // ---------- 5. every insert effect, with A/B/C swept to extremes
    std::printf ("== insert fx\n");
    for (int t = 1; t < pf::InsertFX::NumTypes; ++t)
    {
        float worst = 0; bool fin = true; double cpu = 0;
        for (float v : { 0.0f, 50.0f, 100.0f })
        {
            resetAll (p);
            p.setParam (pid::fx (1, "On"), 1); p.setParam (pid::fx (1, "Type"), (float) t);
            p.setParam (pid::fx (1, "A"), v); p.setParam (pid::fx (1, "B"), 100 - v); p.setParam (pid::fx (1, "C"), v);
            auto r = run (p, ph, sig, &out);
            worst = std::max (worst, r.peak); fin = fin && r.finite; cpu = std::max (cpu, r.cpuPct);
        }
        std::printf ("  %-18s worst peak %6.2f cpu %5.1f%% %s\n", pf::InsertFX::typeName (t), worst, cpu, fin ? "" : "NON-FINITE");
        CHECK (fin && worst < 8.0f, "fx %d unstable", t);
    }

    // ---------- 6. warp: every algorithm in capture and sample mode
    const juce::File smp = outDir.getChildFile ("loop_sample.wav");
    writeWav (sig, smp);
    std::printf ("== warp\n");
    for (int mode : { 1, 2 })
        for (int algo = 0; algo < 5; ++algo)
            for (float speed : { 0.5f, 0.75f, 1.0f, 1.5f })
            {
                resetAll (p);
                if (mode == 2) CHECK (p.loadSample (smp), "sample load failed");
                p.setParam (pid::warpMode, (float) mode); p.setParam (pid::warpAlgo, (float) algo); p.setParam (pid::warpSpeed, speed);
                p.setParam (pid::warpLength, 3);
                auto r = run (p, ph, sig, &out);
                std::printf ("  %-7s %-8s x%.2f  peak %5.2f rms %.3f cpu %5.1f%% %s\n", choices::warpMode[mode].toRawUTF8(), choices::warpAlgo[algo].toRawUTF8(),
                             speed, r.peak, r.rms, r.cpuPct, r.finite ? "" : "NON-FINITE");
                CHECK (r.finite && r.peak < 6.0f && r.rms > 1e-3f, "warp mode %d algo %d speed %.2f bad", mode, algo, speed);
                if (speed == 0.75f) writeWav (out, outDir.getChildFile ("warp_" + choices::warpMode[mode] + "_" + choices::warpAlgo[algo] + ".wav"));
            }
    // freeze & directions
    for (int dir = 0; dir < 3; ++dir)
    {
        resetAll (p);
        p.setParam (pid::warpMode, 1); p.setParam (pid::warpAlgo, 0); p.setParam (pid::warpDir, (float) dir); p.setParam (pid::warpSpeed, 0.8f);
        auto r1 = run (p, ph, sig, nullptr);
        p.setParam (pid::warpFreeze, 1);
        auto r2 = run (p, ph, sig, nullptr);
        std::printf ("  capture dir %d: peak %.2f / frozen peak %.2f rms %.3f\n", dir, r1.peak, r2.peak, r2.rms);
        CHECK (r1.finite && r2.finite && r2.rms > 1e-3f, "freeze/dir %d bad", dir);
    }

    // ---------- 7. tape hiss + sidechain types
    std::printf ("== tape\n");
    for (int h = 0; h < 8; ++h)
        for (int sc = 0; sc < 6; ++sc)
        {
            resetAll (p);
            p.setParam (pid::hissOn, 1); p.setParam (pid::hissType, (float) h); p.setParam (pid::hissSc, (float) sc); p.setParam (pid::hissLevel, -20);
            p.setParam (pid::tapeOn, 1); p.setParam (pid::wow, 60); p.setParam (pid::flutter, 60); p.setParam (pid::tapeDrive, 70);
            auto r = run (p, ph, sig, nullptr);
            CHECK (r.finite && r.peak < 6.0f, "tape hiss %d sc %d bad (peak %.2f)", h, sc, r.peak);
        }
    std::printf ("  8 hiss types x 6 sidechain sources ok\n");

    // ---------- 8. dynamics
    std::printf ("== dynamics\n");
    for (int m = 1; m < 7; ++m)
        for (int st = 0; st < 6; ++st)
        {
            resetAll (p);
            p.setParam (pid::transMode, (float) m); p.setParam (pid::transAttack, 100); p.setParam (pid::transSustain, 100);
            p.setParam (pid::compOn, 1); p.setParam (pid::compStyle, (float) st); p.setParam (pid::compThresh, -30); p.setParam (pid::compMakeup, 6);
            auto r = run (p, ph, sig, nullptr);
            CHECK (r.finite && r.peak < 8.0f, "dyn mode %d style %d bad (peak %.2f)", m, st, r.peak);
        }
    for (size_t i = 0; i < kCompPresets.size(); ++i)
    {
        resetAll (p);
        const auto& c = kCompPresets[i];
        p.setParam (pid::compOn, 1); p.setParam (pid::compStyle, c.style); p.setParam (pid::compThresh, c.thr); p.setParam (pid::compRatio, c.ratio);
        p.setParam (pid::compAttack, c.atk); p.setParam (pid::compRelease, c.rel); p.setParam (pid::compKnee, c.knee); p.setParam (pid::compMakeup, c.makeup); p.setParam (pid::compMix, c.mix);
        auto r = run (p, ph, sig, nullptr);
        std::printf ("  comp preset %-20s peak %.2f rms %.3f gr %.1f dB\n", c.name, r.peak, r.rms, p.compGr.load());
        CHECK (r.finite, "comp preset %zu", i);
    }

    // ---------- 9. every codec at extremes (ZOH at 500 Hz, 8 kbps, 1 bit…)
    std::printf ("== codecs at extremes\n");
    for (int t = 0; t < 7; ++t)
        for (int fr = 0; fr < 5; ++fr)
        {
            resetAll (p);
            p.setParam (pid::lofiOn, 1); p.setParam (pid::codecType, (float) t); p.setParam (pid::codecFrame, (float) fr);
            p.setParam (pid::codecSR, 500); p.setParam (pid::codecKbps, 8); p.setParam (pid::codecBits, 2); p.setParam (pid::codecSwirl, 100);
            p.setParam (pid::codecDither, 1); p.setParam (pid::codecStereo, (float) (fr % 3));
            auto r = run (p, ph, sig, nullptr);
            CHECK (r.finite && r.peak < 4.0f, "codec %d frame %d bad (peak %.2f)", t, fr, r.peak);
        }
    std::printf ("  7 codecs x 5 frame sizes ok\n");

    // ---------- 10. state save/restore round trip
    {
        p.applyPreset (5);
        juce::MemoryBlock mb; p.getStateInformation (mb);
        p.applyPreset (0);
        p.setStateInformation (mb.getData(), (int) mb.getSize());
        const float sp = p.apvts.getRawParameterValue (pid::warpSpeed)->load();
        std::printf ("== state round trip: warpSpeed restored = %.3f\n", sp);
        CHECK (std::abs (sp - 0.84f) < 0.01f, "state restore failed");
    }

    // ---------- 11. editor screenshots + qaeru frames
    {
        p.applyPreset (3);
        run (p, ph, sig, nullptr);
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        auto* e = dynamic_cast<ProtofukrEditor*> (ed.get());
        ed->setVisible (true);
        auto png = [&] (const juce::Image& img, const juce::String& name)
        {
            juce::PNGImageFormat fmt; auto f = outDir.getChildFile (name); f.deleteFile();
            juce::FileOutputStream os (f); fmt.writeImageToStream (img, os);
        };
        run (p, ph, sig, nullptr);
        png (ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f), "ui.png");
        e->triggerScare();
        for (float t : { 0.08f, 0.5f, 0.9f, 1.1f, 1.6f, 2.0f, 3.1f, 3.8f })
        {
            e->getScare().debugTime = t;
            png (ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f), "scare_" + juce::String (t, 2) + ".png");
        }
        std::printf ("== editor rendered (%d x %d)\n", ed->getWidth(), ed->getHeight());
    }

    std::printf ("\n%s (%d failures)\n", failures == 0 ? "ALL TESTS PASSED" : "TESTS FAILED", failures);
    return failures == 0 ? 0 : 1;
}
